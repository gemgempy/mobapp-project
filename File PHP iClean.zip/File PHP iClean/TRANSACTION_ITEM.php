<?php
   header('Content-type:application/json;charset=utf-8');


// create connection to another file
require_once 'include/function_loginreg.php';
$db = new function_loginreg();

// json response array  
// check json response
$response = array("success" => 0); //false

if (isset($_POST['user_id']) && isset($_POST['cucian_id'])) {

    $cucianid = $_POST['cucian_id'];
    $userid = $_POST['user_id'];
    $cartid = $_POST['cart_id'];

    $qty      = ($_POST['qty']);

    $total_price    = ($_POST['total_price']);

    $Address    = ($_POST['address']);


        $user = $db->addto_to_transaction_item($cucianid, $userid, $cartid, $qty, $total_price, $Address);
        if ($user) {

            $response["success"] = 1;//FALSE

            $response["message"] = "Your items has add to transaction!";

            $response["cucian_id"] = $user["cucian_id"];
     

            //displayed in json
            echo json_encode($response);
        } else {
            // user failed to store
            $response["success"] = -2; //TRUE
            $response["message"] = "Error in registration!";
            echo json_encode($response);
        }
    }
 else {
    // if there is a failure in registration
    $response["success"] = -3;//TRUE
    $response["message"] = "Pembayaran berhasil. Tunggu kami konfirmasi!";
    echo json_encode($response);
}
?>