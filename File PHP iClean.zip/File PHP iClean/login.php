<?php

header('Content-type:application/json;charset=utf-8');

// $_POST['name'] = 'asiong';
//$_POST['email'] = 'a1aaa0GsGdfontol@gmail.com';
// $_POST['password'] = '@agusTampan123s';
//$_POST['nohp'] = '0811810293fg939';

// create connection to another file
require_once 'include/function_loginreg.php';
$db = new function_loginreg();

if (empty($_POST['name'])  && isset($_POST['email']) && isset($_POST['password'])) {

    // receiving the post params
    // get data that has been sent before -> POST
    $email = $_POST['email'];
    $password = $_POST['password'];

    // get the user by email and password
    // get data
    $user = $db->getUserByEmailAndPassword($email, $password);

    if ($user != FALSE) {
        // user is found
        // if user is match with database 
        
        $response["success"] = 1;
        $response["message"] = "Login berhasil! Selamat datang kembali~ ".$user["namee"]. " !! ";

// "This email " . $email . " is already registered ! , Try another one" ;



        //parsing value
        $response["namee"] = $user["namee"];
        $response["email"] = $user["email"];
        $response["nohp"] = $user["nohp"];
        
        $response["id_user123"] = $user["id"];


        $response["user"]["namee"] = $user["namee"];
        $response["user"]["email"] = $user["email"];
        $response["user"]["created_at"] = $user["created_at"];
        $response["user"]["updated_at"] = $user["updated_at"];

        // displayed in json
        echo json_encode($response);
    } else {
        // user is not found with the credentials
        // if user not found will appear message
        $response["success"] = -1;
        $response["message"] = "Login not matched. Please try again!";
        echo json_encode($response);
    }
} 
    else if (empty($_POST['email']) && isset($_POST['name']) && isset($_POST['password'])){

        $name = $_POST['name'];
        $password = $_POST['password'];

        $user = $db->getUserByNameAndEmail($name, $password);

    if ($user != FALSE) {
        // use is found
        // if user data match with database, will be displayed user data
        $response["success"] = 1;
        $response["message"] = "Login matched. Welcome back ".$user["namee"]. " !! ";

        
        // parsing value
        $response["namee"] = $user["namee"];
        $response["email"] = $user["email"];
        $response["nohp"] = $user["nohp"];
         $response["id_user123"] = $user["id"];

        $response["user"]["namee"] = $user["namee"];
        $response["user"]["email"] = $user["email"];
        $response["user"]["created_at"] = $user["created_at"];
        $response["user"]["updated_at"] = $user["updated_at"];

        // displayed in json
        echo json_encode($response);
    } else {
        // user is not found with the credentials
        //  if user not found will appear message
        $response["success"] = -1;
        $response["message"] = "Login tidak berhasil. Cocokkan kembali!";
        echo json_encode($response);
    }

}


else {
    // required post params is missing
    // if there's no input login
    $response["success"] = -2;
    $response["message"] = "Parameters email atau password belum diisi!";
    echo json_encode($response);
}

?>