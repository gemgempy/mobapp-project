<?php
   header('Content-type:application/json;charset=utf-8');


// create connection to another file
require_once 'include/function_loginreg.php';
$db = new function_loginreg();

// json response array
// check json response
$response = array("success" => 0); //false

if (isset($_POST['email']) && isset($_POST['password'])) {

    // receiving the post params
    // get data that has been sent
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $nohp      = ($_POST['nohp']);


    // check if user is already existed with the same email
    if ($db->isUserExisted($email)) {
        // user already existed
        
    
        $response["success"] = -1;//TRUE
        //$response["message"] = "This email " . $email . " is already registered ! , Try another one" ;
        $response["message"] = "This email is already registered ! , Try another one" ;
        echo json_encode($response);
    } else {
        // create a new user
        $user = $db->storeUser($name, $email, $password, $nohp);
        if ($user) {
            // user stored successfully
            $response["success"] = 1;//FALSE

            $response["message"] = "Your account has been created!";
        
        //give data to sqlite
            $response["created_att"] = $user["created_at"];
             
            $response["user"]["namee"] = $user["namee"];
            $response["user"]["email"] = $user["email"];
            $response["user"]["nohp"] = $user["nohp"];
            $response["user"]["created_at"] = $user["created_at"];
            $response["user"]["updated_at"] = $user["updated_at"];
            //ditampilkan dalam bentuk json
            echo json_encode($response);
        } else {
            // user failed to store
            $response["success"] = -2; //TRUE
            $response["message"] = "Error in registration!";
            echo json_encode($response);
        }
    }
} else {
    // if there is a failure in registration
    $response["success"] = -3;//TRUE
    $response["message"] = "Parameters is missing!";
    echo json_encode($response);
}
?>