<?php
header('Content-type:application/json;charset=utf-8');
include 'conn.php';

//$conn = new mysqli($server, $user, $password, $database);

//$_POST['id_user'] = '106';

$id_user = $_POST['id_user'];

$select="SELECT c.qty, c.id_cart, b.*
from cart c
inner join cucian b on c.cucian_id = b.id WHERE c.user_id LIKE '$id_user'";

$result=mysqli_query($conn,$select);
$rows=array();
$folder_name="BUAT_UAS/buat_foto/";
$image_folder="photo";
$web_url="https://www.icleanlaundry.my.id/";
$target= "$web_url/$folder_name/$image_folder";

while($row=mysqli_fetch_assoc($result)){
    array_push($rows,array(
        'id'=>$row['id'],
        'name'=>$row['name'],
        'jenis_pakaian'=>$row['jenis_pakaian'],
        'price'=>$row['price'],
        'description'=>$row['description'],
        'image'=>"$target/".$row['image'],
        'max_berat'=>$row['max_berat'],
        'mulai_berlaku'=>$row['mulai_berlaku'],
        'kesulitan'=>$row['kesulitan'],
        'rating'=>$row['rating'],
        'qty'=>$row['qty'],
        'id_cart'=>$row['id_cart']
        
        )
    );
}
echo json_encode($rows);
mysqli_close($conn)


?>