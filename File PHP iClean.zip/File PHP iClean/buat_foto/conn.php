<?php
$servername = "localhost";
$database = "icleanla_wp442";
$username = "icleanla_wp442";
$password = "semangatuas69";

//create connection
$conn = mysqli_connect($servername, $username, $password, $database);
mysqli_select_db($conn, $database) or die("Database belum siap");

//check connection
if (!$conn) {
    
    die("Koneksi gagal: " . mysqli_connect_error());
}

?>


