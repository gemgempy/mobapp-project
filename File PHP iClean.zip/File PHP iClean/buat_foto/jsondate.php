<?php
header('Content-type:application/json;charset=utf-8');
include 'conn.php';

//$conn = new mysqli($server, $user, $password, $database);
$select="SELECT * FROM cucian ORDER BY mulai_berlaku DESC LIMIT 10";

$result=mysqli_query($conn,$select);
$rows=array();
$folder_name="BUAT_UAS/buat_foto/";
$image_folder="photo";
$web_url="https://www.icleanlaundry.my.id/";
$target= "$web_url/$folder_name/$image_folder";
while($row=mysqli_fetch_assoc($result)){
    array_push($rows,array(
        'id'=>$row['id'],
        'name'=>$row['name'],
        'jenis_pakaian'=>$row['jenis_pakaian'],
        'price'=>$row['price'],
        'description'=>$row['description'],
        'image'=>"$target/".$row['image'],
        'max_berat'=>$row['max_berat'],
        'mulai_berlaku'=>$row['mulai_berlaku'],
        'kesulitan'=>$row['kesulitan'],
        'rating'=>$row['rating'],
        'max_jumlah'=>$row['max_jumlah']
        )
    );
}
echo json_encode($rows);
mysqli_close($conn)


?>