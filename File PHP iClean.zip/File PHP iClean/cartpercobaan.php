<?php
   header('Content-type:application/json;charset=utf-8');


// connection to another file
require_once 'include/function_loginreg.php';
$db = new function_loginreg();


$response = array("success" => 0); //false

if (isset($_POST['user_id']) && isset($_POST['cucian_id'])) {


    $userid = $_POST['user_id'];
    $cucianid = $_POST['cucian_id'];
    $qty      = ($_POST['qty']);
    $price    = ($_POST['price']);


        $user = $db->addto_cart($userid, $cucianid, $qty, $price);
        if ($user) {

            $response["success"] = 1;//FALSE

            $response["message"] = "Your items has add to cart!";
            $response["id_pembelian"] = $user["id_cart"];
            $response["user"]["user_id"] = $user["user_id"];
            $response["user"]["cucian_id"] = $user["cucian_id"];
            $response["user"]["qty"] = $user["qty"];
            $response["user"]["price"] = $user["price"];
            //ditampilkan dalam bentuk json
            echo json_encode($response);
        } else {
            
            // if user failed to register
            $response["success"] = -2; //TRUE
            $response["message"] = "Error in registration!";
            echo json_encode($response);
        }
    }
 else {
    // if there is a failure in registration
    $response["success"] = -3;//TRUE
    $response["message"] = "Pembayaranmu berhasil. Tunggu kami konfirmasi!";
    echo json_encode($response);
}
?>