<?php
header('Content-type:application/json;charset=utf-8');
include "conn.php";

require_once 'include/function_loginreg.php';
$db = new function_loginreg();


if (isset($_POST['id_cart']) && isset($_POST['id_cucian']) ) {

    $id = $_POST['id_cart'];
    $cucianid = $_POST['id_cucian'];
    
        $q = mysqli_query($conn, "DELETE FROM cart WHERE id_cart='$id'");

        $response = array();

        if ($q) {
            $response["success"] = 1;
            $response["message"] = "Data berhasil didelete";
            echo json_encode($response);
        } else {
            $response["success"] = 0;
            $response["message"] = "data gagal diupdate";
            echo json_encode($response);
        }
    }
else {
    $response["success"] = -1;
    $response["message"] = "Data kosong";
    echo json_encode($response);
}