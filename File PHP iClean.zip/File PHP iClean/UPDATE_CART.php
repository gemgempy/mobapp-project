<?php
header('Content-type:application/json;charset=utf-8');
include "conn.php";

require_once 'include/function_loginreg.php';
$db = new function_loginreg();


if (isset($_POST['id_cart']) && isset($_POST['cucian_id'])) {

    $id_cart = $_POST['id_cart'];

    $cucian_id = $_POST['cucian_id'];
    $jumlah_cucian = $_POST['QTY'];


        $q = mysqli_query($conn, "UPDATE cart SET qty ='$jumlah_cucian' WHERE cucian_id = '$cucian_id' AND id_cart = '$id_cart' ");

        $response = array();

        if ($q) {
            $response["success"] = 1;
            $response["message"] = "Data berhasil diupdate";
            echo json_encode($response);
        } else {
            $response["success"] = 0;
            $response["message"] = "Data gagal diupdate";
            echo json_encode($response);
        }
    }
else {
    $response["success"] = -1;
    $response["message"] = "Data kosong";
    echo json_encode($response);
}
