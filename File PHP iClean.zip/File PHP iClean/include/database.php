<?php

/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "icleanla_wp442");
define("DB_PASSWORD", "semangatuas69");
define("DB_DATABASE", "icleanla_wp442");


?>