<?php
header('Content-type:application/json;charset=utf-8');
$con = mysqli_connect("localhost", "icleanla_wp442", "semangatuas69", "icleanla_wp442");

if($con){
    if(!empty($_POST['img'])){
        $path = 'images/' . date("d-m-Y") . '-' . time() . '-' . rand(10000, 10000) . '.jpg';
        
        
        $iduser = ($_POST['user_id']);
        $totharga = ($_POST['total_harga']);
        
        if(file_put_contents($path,base64_decode($_POST['img']))){
        $sql = "INSERT INTO payment VALUES('','','$iduser', '$totharga','".$path."')";
        
            if(mysqli_query($con,$sql)){
                
                $response["success"] = 1;
                echo json_encode($response);
            }
            else echo 'Failed to insert to Database';
        }else echo 'Failed to upload image';
    }else echo 'No image Found';    
}
else echo "Database connection failed"; 
